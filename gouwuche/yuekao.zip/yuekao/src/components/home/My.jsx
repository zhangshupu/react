import React, { Component } from 'react'
import PropTypes from 'prop-types'

export class My extends Component {
  static propTypes = {

  }

  render() {
    return (
      <div>
          我的
      </div>
    )
  }
}

export default My
