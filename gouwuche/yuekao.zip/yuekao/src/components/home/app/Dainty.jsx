import React, { Component } from 'react'
import PropTypes from 'prop-types'

export class Dainty extends Component {
  static propTypes = {

  }

  render() {
    return (
      <div>
        纤巧
      </div>
    )
  }
}

export default Dainty
