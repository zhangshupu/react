import React, { Component } from 'react'
import PropTypes from 'prop-types'

export class Suit extends Component {
  static propTypes = {

  }

  render() {
    return (
      <div>
        套装
      </div>
    )
  }
}

export default Suit
