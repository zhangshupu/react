import React, { Component } from 'react'
import PropTypes from 'prop-types'

export class Welfare extends Component {
  static propTypes = {

  }

  render() {
    return (
      <div>
        福利社
      </div>
    )
  }
}

export default Welfare
